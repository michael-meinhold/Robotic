function r = re (q)
  r = q.re;
endfunction
