
function disp (q)
  printf("%f+%f*i+%f*j+%f*k\n", q.re, q.im.x, q.im.y, q.im.z);
endfunction
